<<<FILE: models.js>>>
const path = require('path');
const { Sequelize, DataTypes, Op } = require('sequelize');

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, 'database.db'),
  logging: false
});

// Modelo: Mascota (Pet)
const Pet = sequelize.define('Pet', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  species: {
    type: DataTypes.STRING,
    allowNull: false
  },
  breed: {
    type: DataTypes.STRING,
    allowNull: true
  },
  age: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 1
  },
  ownerName: {
    type: DataTypes.STRING,
    allowNull: false
  },
  ownerPhone: {
    type: DataTypes.STRING,
    allowNull: false
  },
  allergies: {
    type: DataTypes.TEXT,
    allowNull: true,
    defaultValue: 'Ninguna'
  }
}, {
  tableName: 'pets',
  timestamps: true
});

// Modelo: Cita Veterinaria (Appointment)
const Appointment = sequelize.define('Appointment', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  petId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Pet,
      key: 'id'
    }
  },
  doctorName: {
    type: DataTypes.STRING,
    allowNull: false
  },
  dateTime: {
    type: DataTypes.DATE,
    allowNull: false
  },
  reason: {
    type: DataTypes.STRING,
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('PROGRAMADA', 'COMPLETADA', 'CANCELADA'),
    allowNull: false,
    defaultValue: 'PROGRAMADA'
  }
}, {
  tableName: 'appointments',
  timestamps: true
});

// Modelo: Historial Médico (MedicalRecord)
const MedicalRecord = sequelize.define('MedicalRecord', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  petId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Pet,
      key: 'id'
    }
  },
  doctorName: {
    type: DataTypes.STRING,
    allowNull: false
  },
  digitalSignature: {
    type: DataTypes.STRING,
    allowNull: false
  },
  consultationNotes: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  diagnosis: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  treatment: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  appliedVaccines: {
    type: DataTypes.STRING,
    allowNull: true,
    defaultValue: 'Ninguna'
  }
}, {
  tableName: 'medical_records',
  timestamps: true
});

// Modelo: Cobro / Factura (Invoice)
const Invoice = sequelize.define('Invoice', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  petId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: Pet,
      key: 'id'
    }
  },
  clientName: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  subtotal: {
    type: DataTypes.FLOAT,
    allowNull: false
  },
  taxRate: {
    type: DataTypes.FLOAT,
    allowNull: false,
    defaultValue: 0.16
  },
  taxAmount: {
    type: DataTypes.FLOAT,
    allowNull: false
  },
  totalAmount: {
    type: DataTypes.FLOAT,
    allowNull: false
  },
  paymentMethod: {
    type: DataTypes.ENUM('EFECTIVO', 'TARJETA', 'TRANSFERENCIA'),
    allowNull: false,
    defaultValue: 'EFECTIVO'
  },
  status: {
    type: DataTypes.ENUM('PAGADO', 'PENDIENTE', 'ANULADO'),
    allowNull: false,
    defaultValue: 'PAGADO'
  }
}, {
  tableName: 'invoices',
  timestamps: true
});

// Relaciones entre entidades
Pet.hasMany(Appointment, { foreignKey: 'petId', as: 'appointments', onDelete: 'CASCADE' });
Appointment.belongsTo(Pet, { foreignKey: 'petId', as: 'pet' });

Pet.hasMany(MedicalRecord, { foreignKey: 'petId', as: 'medicalRecords', onDelete: 'CASCADE' });
MedicalRecord.belongsTo(Pet, { foreignKey: 'petId', as: 'pet' });

Pet.hasMany(Invoice, { foreignKey: 'petId', as: 'invoices', onDelete: 'SET NULL' });
Invoice.belongsTo(Pet, { foreignKey: 'petId', as: 'pet' });

module.exports = {
  sequelize,
  Op,
  Pet,
  Appointment,
  MedicalRecord,
  Invoice
};
<<<END_FILE>>>

<<<FILE: main.js>>>
const express = require('express');
const cors = require('cors');
const path = require('path');
const swaggerUi = require('swagger-ui-express');
const { sequelize, Op, Pet, Appointment, MedicalRecord, Invoice } = require('./models');

const app = express();
const PORT = process.env.PORT || 8000;

// Middlewares
app.use(cors());
app.use(express.json());

// Especificación OpenAPI 3.0
const swaggerDocument = {
  openapi: '3.0.0',
  info: {
    title: 'Veterinary Clinic Management API',
    version: '1.0.0',
    description: 'API RESTful para gestión de citas veterinarias, historiales médicos y cobranza.'
  },
  servers: [
    {
      url: `http://127.0.0.1:${PORT}`,
      description: 'Servidor Local'
    }
  ],
  paths: {
    '/pets': {
      get: {
        summary: 'Listar o buscar mascotas',
        parameters: [
          {
            name: 'ownerName',
            in: 'query',
            schema: { type: 'string' },
            description: 'Nombre del dueño para filtrar'
          }
        ],
        responses: {
          200: { description: 'Lista de mascotas obtenida exitosamente' },
          500: { description: 'Error interno del servidor' }
        }
      },
      post: {
        summary: 'Registrar una nueva mascota',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['name', 'species', 'age', 'ownerName', 'ownerPhone'],
                properties: {
                  name: { type: 'string', example: 'Firulais' },
                  species: { type: 'string', example: 'Canino' },
                  breed: { type: 'string', example: 'Golden Retriever' },
                  age: { type: 'integer', example: 4 },
                  ownerName: { type: 'string', example: 'Carlos Martinez' },
                  ownerPhone: { type: 'string', example: '5551234567' },
                  allergies: { type: 'string', example: 'Polvo y penicilina' }
                }
              }
            }
          }
        },
        responses: {
          201: { description: 'Mascota creada exitosamente' },
          400: { description: 'Datos obligatorios incompletos' },
          500: { description: 'Error interno del servidor' }
        }
      }
    },
    '/pets/{id}': {
      get: {
        summary: 'Obtener expediente completo de mascota por ID',
        parameters: [
          { name: 'id', in: 'path', required: true, schema: { type: 'integer' } }
        ],
        responses: {
          200: { description: 'Expediente obtenido exitosamente' },
          404: { description: 'Mascota no encontrada' },
          500: { description: 'Error interno del servidor' }
        }
      },
      put: {
        summary: 'Actualizar información de una mascota',
        parameters: [
          { name: 'id', in: 'path', required: true, schema: { type: 'integer' } }
        ],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  species: { type: 'string' },
                  breed: { type: 'string' },
                  age: { type: 'integer' },
                  ownerName: { type: 'string' },
                  ownerPhone: { type: 'string' },
                  allergies: { type: 'string' }
                }
              }
            }
          }
        },
        responses: {
          200: { description: 'Mascota actualizada' },
          404: { description: 'Mascota no encontrada' },
          500: { description: 'Error interno del servidor' }
        }
      },
      delete: {
        summary: 'Eliminar una mascota',
        parameters: [
          { name: 'id', in: 'path', required: true, schema: { type: 'integer' } }
        ],
        responses: {
          200: { description: 'Mascota eliminada' },
          404: { description: 'Mascota no encontrada' },
          500: { description: 'Error interno del servidor' }
        }
      }
    },
    '/appointments': {
      get: {
        summary: 'Listar citas agendadas',
        parameters: [
          { name: 'date', in: 'query', schema: { type: 'string' }, description: 'Fecha YYYY-MM-DD' },
          { name: 'doctorName', in: 'query', schema: { type: 'string' } }
        ],
        responses: {
          200: { description: 'Lista de citas obtenida' },
          500: { description: 'Error interno del servidor' }
        }
      },
      post: {
        summary: 'Crear una nueva cita verificando disponibilidad de horario',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['petId', 'doctorName', 'dateTime', 'reason'],
                properties: {
                  petId: { type: 'integer', example: 1 },
                  doctorName: { type: 'string', example: 'Dr. Lopez' },
                  dateTime: { type: 'string', example: '2026-04-15T10:00:00.000Z' },
                  reason: { type: 'string', example: 'Vacunación y chequeo general' }
                }
              }
            }
          }
        },
        responses: {
          201: { description: 'Cita programada con éxito' },
          400: { description: 'Horario no disponible o datos incompletos' },
          404: { description: 'Mascota no encontrada' },
          500: { description: 'Error interno del servidor' }
        }
      }
    },
    '/appointments/{id}': {
      get: {
        summary: 'Obtener detalle de una cita',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: {
          200: { description: 'Cita encontrada' },
          404: { description: 'Cita no encontrada' },
          500: { description: 'Error interno del servidor' }
        }
      },
      put: {
        summary: 'Actualizar datos o reprogramar cita',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  dateTime: { type: 'string', example: '2026-04-15T11:00:00.000Z' },
                  doctorName: { type: 'string' },
                  reason: { type: 'string' },
                  status: { type: 'string', enum: ['PROGRAMADA', 'COMPLETADA', 'CANCELADA'] }
                }
              }
            }
          }
        },
        responses: {
          200: { description: 'Cita actualizada' },
          400: { description: 'Horario no disponible' },
          404: { description: 'Cita no encontrada' },
          500: { description: 'Error interno del servidor' }
        }
      },
      delete: {
        summary: 'Cancelar / Eliminar cita',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: {
          200: { description: 'Cita eliminada' },
          404: { description: 'Cita no encontrada' },
          500: { description: 'Error interno del servidor' }
        }
      }
    },
    '/medical-records': {
      get: {
        summary: 'Listar registros médicos',
        responses: {
          200: { description: 'Historiales obtenidos' },
          500: { description: 'Error interno del servidor' }
        }
      },
      post: {
        summary: 'Registrar nueva nota médica con firma digital',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['petId', 'doctorName', 'digitalSignature', 'consultationNotes', 'diagnosis', 'treatment'],
                properties: {
                  petId: { type: 'integer', example: 1 },
                  doctorName: { type: 'string', example: 'Dra. Ramirez' },
                  digitalSignature: { type: 'string', example: 'SIG-DR-RAMIREZ-9821' },
                  consultationNotes: { type: 'string', example: 'Paciente alerta con temperatura normal.' },
                  diagnosis: { type: 'string', example: 'Gastroenteritis leve' },
                  treatment: { type: 'string', example: 'Dieta blanda y probióticos por 5 días' },
                  appliedVaccines: { type: 'string', example: 'Rabia' }
                }
              }
            }
          }
        },
        responses: {
          201: { description: 'Nota de historial médico agregada' },
          400: { description: 'Datos obligatorios incompletos' },
          404: { description: 'Mascota no encontrada' },
          500: { description: 'Error interno del servidor' }
        }
      }
    },
    '/medical-records/{id}': {
      get: {
        summary: 'Obtener nota médica por ID',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: {
          200: { description: 'Nota médica encontrada' },
          404: { description: 'Registro no encontrado' },
          500: { description: 'Error interno del servidor' }
        }
      },
      put: {
        summary: 'Actualizar nota médica',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  consultationNotes: { type: 'string' },
                  diagnosis: { type: 'string' },
                  treatment: { type: 'string' },
                  appliedVaccines: { type: 'string' }
                }
              }
            }
          }
        },
        responses: {
          200: { description: 'Nota actualizada' },
          404: { description: 'Registro no encontrado' },
          500: { description: 'Error interno del servidor' }
        }
      },
      delete: {
        summary: 'Eliminar registro médico',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: {
          200: { description: 'Registro eliminado' },
          404: { description: 'Registro no encontrado' },
          500: { description: 'Error interno del servidor' }
        }
      }
    },
    '/invoices': {
      get: {
        summary: 'Listar comprobantes y pagos',
        responses: {
          200: { description: 'Lista de cobros obtenida' },
          500: { description: 'Error interno del servidor' }
        }
      },
      post: {
        summary: 'Generar cobro y ticket con cálculo automático de impuestos',
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                required: ['clientName', 'description', 'subtotal'],
                properties: {
                  petId: { type: 'integer', example: 1 },
                  clientName: { type: 'string', example: 'Carlos Martinez' },
                  description: { type: 'string', example: 'Consulta general + Vacuna Rabia' },
                  subtotal: { type: 'number', example: 850.00 },
                  paymentMethod: { type: 'string', enum: ['EFECTIVO', 'TARJETA', 'TRANSFERENCIA'], example: 'TARJETA' }
                }
              }
            }
          }
        },
        responses: {
          201: { description: 'Ticket generado exitosamente' },
          400: { description: 'Datos requeridos faltantes' },
          500: { description: 'Error interno del servidor' }
        }
      }
    },
    '/invoices/{id}': {
      get: {
        summary: 'Obtener detalle de comprobante por ID',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: {
          200: { description: 'Comprobante encontrado' },
          404: { description: 'Comprobante no encontrado' },
          500: { description: 'Error interno del servidor' }
        }
      },
      put: {
        summary: 'Actualizar comprobante de pago',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  status: { type: 'string', enum: ['PAGADO', 'PENDIENTE', 'ANULADO'] },
                  paymentMethod: { type: 'string', enum: ['EFECTIVO', 'TARJETA', 'TRANSFERENCIA'] }
                }
              }
            }
          }
        },
        responses: {
          200: { description: 'Comprobante actualizado' },
          404: { description: 'Comprobante no encontrado' },
          500: { description: 'Error interno del servidor' }
        }
      },
      delete: {
        summary: 'Eliminar comprobante',
        parameters: [{ name: 'id', in: 'path', required: true, schema: { type: 'integer' } }],
        responses: {
          200: { description: 'Comprobante eliminado' },
          404: { description: 'Comprobante no encontrado' },
          500: { description: 'Error interno del servidor' }
        }
      }
    },
    '/invoices/reports/daily': {
      get: {
        summary: 'Reporte de caja diario y total acumulado de ingresos',
        parameters: [
          { name: 'date', in: 'query', schema: { type: 'string' }, description: 'Fecha YYYY-MM-DD (por defecto hoy)' }
        ],
        responses: {
          200: { description: 'Reporte de caja generado' },
          500: { description: 'Error interno del servidor' }
        }
      }
    }
  }
};

// Documentación Swagger en /docs
app.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// ==========================================
// RUTAS: MASCOTAS (PETS)
// ==========================================

// Listar mascotas (con filtro opcional por ownerName)
app.get('/pets', async (req, res) => {
  try {
    const { ownerName } = req.query;
    const filter = {};
    if (ownerName) {
      filter.ownerName = { [Op.like]: `%${ownerName}%` };
    }
    const pets = await Pet.findAll({
      where: filter,
      include: [
        { model: MedicalRecord, as: 'medicalRecords' },
        { model: Appointment, as: 'appointments' }
      ]
    });
    return res.status(200).json(pets);
  } catch (error) {
    return res.status(500).json({ error: 'Error al consultar mascotas', details: error.message });
  }
});

// Obtener mascota por ID con expediente completo
app.get('/pets/:id', async (req, res) => {
  try {
    const pet = await Pet.findByPk(req.params.id, {
      include: [
        { model: MedicalRecord, as: 'medicalRecords' },
        { model: Appointment, as: 'appointments' },
        { model: Invoice, as: 'invoices' }
      ]
    });
    if (!pet) {
      return res.status(404).json({ error: 'Mascota no encontrada' });
    }
    return res.status(200).json(pet);
  } catch (error) {
    return res.status(500).json({ error: 'Error al consultar mascota', details: error.message });
  }
});

// Crear nueva mascota
app.post('/pets', async (req, res) => {
  try {
    const { name, species, breed, age, ownerName, ownerPhone, allergies } = req.body;
    if (!name || !species || !age || !ownerName || !ownerPhone) {
      return res.status(400).json({ error: 'Faltan campos obligatorios: name, species, age, ownerName, ownerPhone' });
    }
    const newPet = await Pet.create({
      name,
      species,
      breed,
      age,
      ownerName,
      ownerPhone,
      allergies: allergies || 'Ninguna'
    });
    return res.status(201).json(newPet);
  } catch (error) {
    return res.status(500).json({ error: 'Error al registrar mascota', details: error.message });
  }
});

// Actualizar mascota
app.put('/pets/:id', async (req, res) => {
  try {
    const pet = await Pet.findByPk(req.params.id);
    if (!pet) {
      return res.status(404).json({ error: 'Mascota no encontrada' });
    }
    await pet.update(req.body);
    return res.status(200).json(pet);
  } catch (error) {
    return res.status(500).json({ error: 'Error al actualizar mascota', details: error.message });
  }
});

// Eliminar mascota
app.delete('/pets/:id', async (req, res) => {
  try {
    const pet = await Pet.findByPk(req.params.id);
    if (!pet) {
      return res.status(404).json({ error: 'Mascota no encontrada' });
    }
    await pet.destroy();
    return res.status(200).json({ message: 'Mascota eliminada correctamente' });
  } catch (error) {
    return res.status(500).json({ error: 'Error al eliminar mascota', details: error.message });
  }
});

// ==========================================
// RUTAS: CITAS (APPOINTMENTS)
// ==========================================

// Listar citas
app.get('/appointments', async (req, res) => {
  try {
    const { doctorName, date } = req.query;
    const filter = {};
    if (doctorName) {
      filter.doctorName = doctorName;
    }
    if (date) {
      const startOfDay = new Date(`${date}T00:00:00.000Z`);
      const endOfDay = new Date(`${date}T23:59:59.999Z`);
      filter.dateTime = { [Op.between]: [startOfDay, endOfDay] };
    }
    const appointments = await Appointment.findAll({
      where: filter,
      include: [{ model: Pet, as: 'pet' }],
      order: [['dateTime', 'ASC']]
    });
    return res.status(200).json(appointments);
  } catch (error) {
    return res.status(500).json({ error: 'Error al consultar citas', details: error.message });
  }
});

// Obtener cita por ID
app.get('/appointments/:id', async (req, res) => {
  try {
    const appointment = await Appointment.findByPk(req.params.id, {
      include: [{ model: Pet, as: 'pet' }]
    });
    if (!appointment) {
      return res.status(404).json({ error: 'Cita no encontrada' });
    }
    return res.status(200).json(appointment);
  } catch (error) {
    return res.status(500).json({ error: 'Error al obtener cita', details: error.message });
  }
});

// Crear cita con validación estricta de traslape / agenda
app.post('/appointments', async (req, res) => {
  try {
    const { petId, doctorName, dateTime, reason } = req.body;
    if (!petId || !doctorName || !dateTime || !reason) {
      return res.status(400).json({ error: 'Faltan campos obligatorios: petId, doctorName, dateTime, reason' });
    }

    const pet = await Pet.findByPk(petId);
    if (!pet) {
      return res.status(404).json({ error: 'La mascota especificada no existe' });
    }

    // Regla de Negocio: Validar horario ya ocupado por el mismo médico
    const appointmentDate = new Date(dateTime);
    const existingAppointment = await Appointment.findOne({
      where: {
        doctorName,
        dateTime: appointmentDate,
        status: { [Op.ne]: 'CANCELADA' }
      }
    });

    if (existingAppointment) {
      return res.status(400).json({ error: 'Horario no disponible' });
    }

    const newAppointment = await Appointment.create({
      petId,
      doctorName,
      dateTime: appointmentDate,
      reason,
      status: 'PROGRAMADA'
    });

    const populatedAppointment = await Appointment.findByPk(newAppointment.id, {
      include: [{ model: Pet, as: 'pet' }]
    });

    return res.status(201).json(populatedAppointment);
  } catch (error) {
    return res.status(500).json({ error: 'Error al agendar cita', details: error.message });
  }
});

// Actualizar o reprogramar cita
app.put('/appointments/:id', async (req, res) => {
  try {
    const appointment = await Appointment.findByPk(req.params.id);
    if (!appointment) {
      return res.status(404).json({ error: 'Cita no encontrada' });
    }

    const { dateTime, doctorName, reason, status } = req.body;
    const targetDoctor = doctorName || appointment.doctorName;
    const targetDate = dateTime ? new Date(dateTime) : appointment.dateTime;

    if (dateTime || doctorName) {
      const conflict = await Appointment.findOne({
        where: {
          id: { [Op.ne]: appointment.id },
          doctorName: targetDoctor,
          dateTime: targetDate,
          status: { [Op.ne]: 'CANCELADA' }
        }
      });

      if (conflict) {
        return res.status(400).json({ error: 'Horario no disponible' });
      }
    }

    await appointment.update({
      dateTime: targetDate,
      doctorName: targetDoctor,
      reason: reason !== undefined ? reason : appointment.reason,
      status: status !== undefined ? status : appointment.status
    });

    return res.status(200).json(appointment);
  } catch (error) {
    return res.status(500).json({ error: 'Error al actualizar cita', details: error.message });
  }
});

// Eliminar cita
app.delete('/appointments/:id', async (req, res) => {
  try {
    const appointment = await Appointment.findByPk(req.params.id);
    if (!appointment) {
      return res.status(404).json({ error: 'Cita no encontrada' });
    }
    await appointment.destroy();
    return res.status(200).json({ message: 'Cita eliminada correctamente' });
  } catch (error) {
    return res.status(500).json({ error: 'Error al eliminar cita', details: error.message });
  }
});

// ==========================================
// RUTAS: HISTORIAL MÉDICO (MEDICAL RECORDS)
// ==========================================

// Listar historial médico general
app.get('/medical-records', async (req, res) => {
  try {
    const records = await MedicalRecord.findAll({
      include: [{ model: Pet, as: 'pet' }],
      order: [['createdAt', 'DESC']]
    });
    return res.status(200).json(records);
  } catch (error) {
    return res.status(500).json({ error: 'Error al obtener registros médicos', details: error.message });
  }
});

// Obtener nota médica individual
app.get('/medical-records/:id', async (req, res) => {
  try {
    const record = await MedicalRecord.findByPk(req.params.id, {
      include: [{ model: Pet, as: 'pet' }]
    });
    if (!record) {
      return res.status(404).json({ error: 'Registro médico no encontrado' });
    }
    return res.status(200).json(record);
  } catch (error) {
    return res.status(500).json({ error: 'Error al obtener nota médica', details: error.message });
  }
});

// Registrar nueva nota de consulta con firma digital
app.post('/medical-records', async (req, res) => {
  try {
    const { petId, doctorName, digitalSignature, consultationNotes, diagnosis, treatment, appliedVaccines } = req.body;
    if (!petId || !doctorName || !digitalSignature || !consultationNotes || !diagnosis || !treatment) {
      return res.status(400).json({
        error: 'Faltan campos obligatorios: petId, doctorName, digitalSignature, consultationNotes, diagnosis, treatment'
      });
    }

    const pet = await Pet.findByPk(petId);
    if (!pet) {
      return res.status(404).json({ error: 'La mascota especificada no existe' });
    }

    const record = await MedicalRecord.create({
      petId,
      doctorName,
      digitalSignature,
      consultationNotes,
      diagnosis,
      treatment,
      appliedVaccines: appliedVaccines || 'Ninguna'
    });

    return res.status(201).json(record);
  } catch (error) {
    return res.status(500).json({ error: 'Error al registrar historial médico', details: error.message });
  }
});

// Actualizar nota médica
app.put('/medical-records/:id', async (req, res) => {
  try {
    const record = await MedicalRecord.findByPk(req.params.id);
    if (!record) {
      return res.status(404).json({ error: 'Registro médico no encontrado' });
    }
    await record.update(req.body);
    return res.status(200).json(record);
  } catch (error) {
    return res.status(500).json({ error: 'Error al actualizar registro médico', details: error.message });
  }
});

// Eliminar nota médica
app.delete('/medical-records/:id', async (req, res) => {
  try {
    const record = await MedicalRecord.findByPk(req.params.id);
    if (!record) {
      return res.status(404).json({ error: 'Registro médico no encontrado' });
    }
    await record.destroy();
    return res.status(200).json({ message: 'Registro médico eliminado correctamente' });
  } catch (error) {
    return res.status(500).json({ error: 'Error al eliminar registro médico', details: error.message });
  }
});

// ==========================================
// RUTAS: COBROS Y CAJA (INVOICES)
// ==========================================

// Reporte de ingresos del día
app.get('/invoices/reports/daily', async (req, res) => {
  try {
    const targetDateStr = req.query.date || new Date().toISOString().split('T')[0];
    const startOfDay = new Date(`${targetDateStr}T00:00:00.000Z`);
    const endOfDay = new Date(`${targetDateStr}T23:59:59.999Z`);

    const dailyInvoices = await Invoice.findAll({
      where: {
        createdAt: { [Op.between]: [startOfDay, endOfDay] },
        status: 'PAGADO'
      }
    });

    const totalIncome = dailyInvoices.reduce((acc, invoice) => acc + invoice.totalAmount, 0);
    const totalTax = dailyInvoices.reduce((acc, invoice) => acc + invoice.taxAmount, 0);
    const totalSubtotal = dailyInvoices.reduce((acc, invoice) => acc + invoice.subtotal, 0);

    return res.status(200).json({
      date: targetDateStr,
      transactionsCount: dailyInvoices.length,
      subtotalGeneral: parseFloat(totalSubtotal.toFixed(2)),
      impuestosTotales: parseFloat(totalTax.toFixed(2)),
      ingresosTotales: parseFloat(totalIncome.toFixed(2)),
      detalles: dailyInvoices
    });
  } catch (error) {
    return res.status(500).json({ error: 'Error al generar reporte de caja', details: error.message });
  }
});

// Listar facturas
app.get('/invoices', async (req, res) => {
  try {
    const invoices = await Invoice.findAll({
      include: [{ model: Pet, as: 'pet' }],
      order: [['createdAt', 'DESC']]
    });
    return res.status(200).json(invoices);
  } catch (error) {
    return res.status(500).json({ error: 'Error al consultar cobros', details: error.message });
  }
});

// Obtener factura por ID
app.get('/invoices/:id', async (req, res) => {
  try {
    const invoice = await Invoice.findByPk(req.params.id, {
      include: [{ model: Pet, as: 'pet' }]
    });
    if (!invoice) {
      return res.status(404).json({ error: 'Comprobante no encontrado' });
    }
    return res.status(200).json(invoice);
  } catch (error) {
    return res.status(500).json({ error: 'Error al consultar comprobante', details: error.message });
  }
});

// Generar cobro con cálculo de impuestos y ticket digital
app.post('/invoices', async (req, res) => {
  try {
    const { petId, clientName, description, subtotal, paymentMethod, status } = req.body;
    if (!clientName || !description || subtotal === undefined || subtotal === null) {
      return res.status(400).json({ error: 'Faltan campos obligatorios: clientName, description, subtotal' });
    }

    const subtotalNum = parseFloat(subtotal);
    if (isNaN(subtotalNum) || subtotalNum < 0) {
      return res.status(400).json({ error: 'El subtotal debe ser un número positivo' });
    }

    const taxRate = 0.16;
    const taxAmount = parseFloat((subtotalNum * taxRate).toFixed(2));
    const totalAmount = parseFloat((subtotalNum + taxAmount).toFixed(2));

    const invoice = await Invoice.create({
      petId: petId || null,
      clientName,
      description,
      subtotal: subtotalNum,
      taxRate,
      taxAmount,
      totalAmount,
      paymentMethod: paymentMethod || 'EFECTIVO',
      status: status || 'PAGADO'
    });

    const ticket = {
      ticketNumber: `TKT-${String(invoice.id).padStart(6, '0')}`,
      date: invoice.createdAt,
      client: invoice.clientName,
      items: invoice.description,
      subtotal: invoice.subtotal,
      iva_16: invoice.taxAmount,
      total: invoice.totalAmount,
      paymentMethod: invoice.paymentMethod,
      paymentStatus: invoice.status,
      receiptDetails: invoice
    };

    return res.status(201).json(ticket);
  } catch (error) {
    return res.status(500).json({ error: 'Error al generar cobro', details: error.message });
  }
});

// Actualizar comprobante
app.put('/invoices/:id', async (req, res) => {
  try {
    const invoice = await Invoice.findByPk(req.params.id);
    if (!invoice) {
      return res.status(404).json({ error: 'Comprobante no encontrado' });
    }

    const { status, paymentMethod } = req.body;
    await invoice.update({
      status: status !== undefined ? status : invoice.status,
      paymentMethod: paymentMethod !== undefined ? paymentMethod : invoice.paymentMethod
    });

    return res.status(200).json(invoice);
  } catch (error) {
    return res.status(500).json({ error: 'Error al actualizar comprobante', details: error.message });
  }
});

// Eliminar comprobante
app.delete('/invoices/:id', async (req, res) => {
  try {
    const invoice = await Invoice.findByPk(req.params.id);
    if (!invoice) {
      return res.status(404).json({ error: 'Comprobante no encontrado' });
    }
    await invoice.destroy();
    return res.status(200).json({ message: 'Comprobante eliminado exitosamente' });
  } catch (error) {
    return res.status(500).json({ error: 'Error al eliminar comprobante', details: error.message });
  }
});

// Inicialización de servidor y base de datos
async function startServer() {
  try {
    await sequelize.sync({ alter: true });
    console.log('Base de datos SQLite sincronizada exitosamente.');

    app.listen(PORT, () => {
      console.log(`Servidor backend veterinario ejecutándose en http://127.0.0.1:${PORT}`);
      console.log(`Documentación OpenAPI disponible en http://127.0.0.1:${PORT}/docs`);
    });
  } catch (error) {
    console.error('Error al inicializar el servidor:', error);
    process.exit(1);
  }
}

startServer();

module.exports = app;
<<<END_FILE>>>

<<<FILE: requirements.txt>>>
express
cors
sequelize
sqlite3
swagger-ui-express
dotenv
<<<END_FILE>>>

<<<FILE: package.json>>>
{
  "name": "veterinary-backend-system",
  "version": "1.0.0",
  "description": "Sistema RESTful backend para gestión de clínica veterinaria con Express, SQLite y Swagger",
  "main": "main.js",
  "scripts": {
    "start": "node main.js"
  },
  "dependencies": {
    "cors": "^2.8.5",
    "dotenv": "^16.4.7",
    "express": "^4.21.2",
    "sequelize": "^6.37.5",
    "sqlite3": "^5.1.7",
    "swagger-ui-express": "^5.0.1"
  },
  "keywords": [
    "veterinary",
    "express",
    "rest-api",
    "sqlite",
    "swagger"
  ],
  "author": "Balam_Developer",
  "license": "ISC"
}
<<<END_FILE>>>
const path = require('path');
const { Sequelize, DataTypes, Op } = require('sequelize');

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: path.join(__dirname, 'database.db'),
  logging: false
});

// Modelo: Mascota (Pet)
const Pet = sequelize.define('Pet', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  species: {
    type: DataTypes.STRING,
    allowNull: false
  },
  breed: {
    type: DataTypes.STRING,
    allowNull: true
  },
  age: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 1
  },
  ownerName: {
    type: DataTypes.STRING,
    allowNull: false
  },
  ownerPhone: {
    type: DataTypes.STRING,
    allowNull: false
  },
  allergies: {
    type: DataTypes.TEXT,
    allowNull: true,
    defaultValue: 'Ninguna'
  }
}, {
  tableName: 'pets',
  timestamps: true
});

// Modelo: Cita Veterinaria (Appointment)
const Appointment = sequelize.define('Appointment', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  petId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Pet,
      key: 'id'
    }
  },
  doctorName: {
    type: DataTypes.STRING,
    allowNull: false
  },
  dateTime: {
    type: DataTypes.DATE,
    allowNull: false
  },
  reason: {
    type: DataTypes.STRING,
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('PROGRAMADA', 'COMPLETADA', 'CANCELADA'),
    allowNull: false,
    defaultValue: 'PROGRAMADA'
  }
}, {
  tableName: 'appointments',
  timestamps: true
});

// Modelo: Historial Médico (MedicalRecord)
const MedicalRecord = sequelize.define('MedicalRecord', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  petId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Pet,
      key: 'id'
    }
  },
  doctorName: {
    type: DataTypes.STRING,
    allowNull: false
  },
  digitalSignature: {
    type: DataTypes.STRING,
    allowNull: false
  },
  consultationNotes: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  diagnosis: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  treatment: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  appliedVaccines: {
    type: DataTypes.STRING,
    allowNull: true,
    defaultValue: 'Ninguna'
  }
}, {
  tableName: 'medical_records',
  timestamps: true
});

// Modelo: Cobro / Factura (Invoice)
const Invoice = sequelize.define('Invoice', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  petId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: Pet,
      key: 'id'
    }
  },
  clientName: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  subtotal: {
    type: DataTypes.FLOAT,
    allowNull: false
  },
  taxRate: {
    type: DataTypes.FLOAT,
    allowNull: false,
    defaultValue: 0.16
  },
  taxAmount: {
    type: DataTypes.FLOAT,
    allowNull: false
  },
  totalAmount: {
    type: DataTypes.FLOAT,
    allowNull: false
  },
  paymentMethod: {
    type: DataTypes.ENUM('EFECTIVO', 'TARJETA', 'TRANSFERENCIA'),
    allowNull: false,
    defaultValue: 'EFECTIVO'
  },
  status: {
    type: DataTypes.ENUM('PAGADO', 'PENDIENTE', 'ANULADO'),
    allowNull: false,
    defaultValue: 'PAGADO'
  }
}, {
  tableName: 'invoices',
  timestamps: true
});

// Relaciones entre entidades
Pet.hasMany(Appointment, { foreignKey: 'petId', as: 'appointments', onDelete: 'CASCADE' });
Appointment.belongsTo(Pet, { foreignKey: 'petId', as: 'pet' });

Pet.hasMany(MedicalRecord, { foreignKey: 'petId', as: 'medicalRecords', onDelete: 'CASCADE' });
MedicalRecord.belongsTo(Pet, { foreignKey: 'petId', as: 'pet' });

Pet.hasMany(Invoice, { foreignKey: 'petId', as: 'invoices', onDelete: 'SET NULL' });
Invoice.belongsTo(Pet, { foreignKey: 'petId', as: 'pet' });

module.exports = {
  sequelize,
  Op,
  Pet,
  Appointment,
  MedicalRecord,
  Invoice
};
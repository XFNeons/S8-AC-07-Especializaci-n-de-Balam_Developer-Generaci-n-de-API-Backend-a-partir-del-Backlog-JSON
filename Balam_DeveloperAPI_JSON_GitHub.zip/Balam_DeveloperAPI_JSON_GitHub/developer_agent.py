import os
import sys
import re
import json
import subprocess
from pathlib import Path
from crewai import Agent, Task, Crew, Process, LLM
from dotenv import load_dotenv

# Asegurar codificación UTF-8 en consola para Windows
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

# Cargar variables de entorno (API Key de Gemini)
load_dotenv()
os.environ["PYTHONIOENCODING"] = "utf-8"

api_key = os.getenv("GEMINI_API_KEY")
if not api_key:
    raise ValueError("No se encontró la GEMINI_API_KEY en las variables de entorno o archivo .env")

# Propagar a los SDKs subyacentes
os.environ["GOOGLE_API_KEY"] = api_key
os.environ["GEMINI_API_KEY"] = api_key

# Configurar el modelo LLM (usando gemini-3.8-flash compatible con la API actual)
gemini_model = os.getenv("GEMINI_MODEL", "gemini/gemini-3.8-flash")
llm_gemini = LLM(
    model=gemini_model,
    api_key=api_key
)

# ---------------------------------------------------------------------------
# Parte 1: Diseño y Calibración del Agente (Balam_Developer)
# ---------------------------------------------------------------------------
balam_developer = Agent(
    role="Senior Backend Engineer & API Architect",
    goal=(
        "Leer un archivo backlog.json de forma estructurada y generar código de "
        "backend RESTful limpio, modular y funcional en Node.js/Express sin intervención humana."
    ),
    backstory=(
        "Eres Balam_Developer, un Ingeniero Backend Senior experto en React, clean code "
        "y arquitectura RESTful. Tu misión es tomar requerimientos técnicos y funcionales "
        "desde un archivo backlog en formato JSON y programar código de backend RESTful robusto, "
        "aplicando buenas prácticas, validaciones estrictas y evitando librerías obsoletas. "
        "Generas arquitecturas limpias, escalables y archivos ejecutables listos para producción "
        "o pruebas locales inmediatas con documentación interactiva Swagger/OpenAPI."
    ),
    verbose=True,
    allow_delegation=False,
    llm=llm_gemini
)

def build_prompt_maestro(backlog_content: str) -> str:
    """Construye el prompt maestro calibrado con reglas estrictas anti-librerías obsoletas y anti-errores sintácticos."""
    return f"""
Actúa como Balam_Developer (Ingeniero Backend Senior experto en React, clean code y arquitectura RESTful).
Tu tarea es analizar el siguiente Product Backlog en formato JSON y construir el código fuente completo,
modular y 100% funcional para el backend RESTful del sistema.

=== PRODUCT BACKLOG (JSON) ===
{backlog_content}
==============================

=== REGLAS OBLIGATORIAS DE CALIBRACIÓN TÉCNICA ===
1. Sintaxis CommonJS estricta: Usa 'require()' y 'module.exports' en todos los archivos .js para evitar errores de tipo 'Cannot use import statement outside a module'.
2. Cero librerías obsoletas: NO uses 'body-parser' (usa el middleware nativo 'express.json()'). NO uses paquetes desactualizados ni sintaxis deprecadas de ORM.
3. Base de Datos Local y ORM (Sequelize):
   - Configura Sequelize utilizando SQLite ligero apuntando a un archivo local 'database.db' (dialect: 'sqlite', storage: path.join(__dirname, 'database.db'), logging: false).
   - Esto permite compatibilidad con modelos relacionales tipo PostgreSQL pero con inicialización ligera automática en 'database.db' sin requerir instalación previa de servidores externos.
   - Sincroniza la base de datos automáticamente al arrancar la aplicación (`await sequelize.sync({{ alter: true }})`).
4. Documentación Interactiva Swagger/OpenAPI en /docs:
   - Configura 'swagger-ui-express' en la ruta exacta '/docs' (para que responda en http://127.0.0.1:8000/docs).
   - La especificación OpenAPI 3.0 debe estar completamente definida en un objeto JSON/JS con títulos, esquemas de datos y endpoints CRUD (mínimo GET y POST documentados con parámetros y ejemplos de body).
5. Endpoints CRUD completos para las entidades del Backlog:
   - Implementa operaciones completas: GET (listar todos), GET por ID, POST (crear con validación de campos obligatorios), PUT (actualizar) y DELETE (eliminar).
   - Respuestas con códigos de estado HTTP semánticos: 200 (OK), 201 (Created), 400 (Bad Request si faltan datos), 404 (Not Found), 500 (Internal Error).
   - Manejo de excepciones con bloques try/catch en todas las rutas asíncronas.
6. Puerto de ejecución: El servidor debe escuchar en el puerto 8000 (`const PORT = process.env.PORT || 8000;`).
7. Código 100% completo: No uses comentarios tipo '// TODO', '// agrega aquí el resto', ni elipsis '...'. Escribe cada archivo de principio a fin listo para ejecutar.

=== FORMATO DE ENTREGA OBLIGATORIO ===
Debes entregar el código de cada archivo separado exactamente con estos delimitadores especiales:

<<<FILE: models.js>>>
[Código completo de models.js con conexión Sequelize a database.db, definición de modelos, relaciones y exportación de modelos y sequelize]
<<<END_FILE>>>

<<<FILE: main.js>>>
[Código completo de main.js con Express, CORS, express.json(), Swagger en /docs, rutas CRUD de los modelos y app.listen(8000)]
<<<END_FILE>>>

<<<FILE: requirements.txt>>>
[Lista de dependencias requeridas: express, cors, sequelize, sqlite3, swagger-ui-express, dotenv]
<<<END_FILE>>>

<<<FILE: package.json>>>
[package.json válido con nombre, versión, "scripts": {{"start": "node main.js"}}, y dependencias: express, cors, sequelize, sqlite3, swagger-ui-express, dotenv]
<<<END_FILE>>>
"""

def extract_and_save_files(crew_output: str, output_dir: str = "generated_backend"):
    """Extrae de forma autónoma los archivos generados por Balam_Developer y los guarda en disco."""
    os.makedirs(output_dir, exist_ok=True)
    
    # 1. Guardar el reporte completo
    report_path = os.path.join(output_dir, "development_report.md")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(crew_output)
    print(f"-> Reporte de desarrollo guardado en: {report_path}")

    # 2. Extraer archivos usando el delimitador <<<FILE: filename>>> ... <<<END_FILE>>>
    pattern = r"<<<FILE:\s*([^\n>]+)>>>\s*(.*?)\s*<<<END_FILE>>>"
    matches = re.findall(pattern, crew_output, re.DOTALL)
    
    saved_files = []
    
    if matches:
        for filename, content in matches:
            filename = filename.strip()
            # Limpiar posibles bloques markdown envolventes si el LLM los colocó
            clean_content = content.strip()
            if clean_content.startswith("```"):
                clean_content = re.sub(r"^```[a-zA-Z0-9_-]*\n", "", clean_content)
                clean_content = re.sub(r"\n```$", "", clean_content)
            
            filepath = os.path.join(output_dir, filename)
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(clean_content)
            saved_files.append(filename)
            print(f"-> Archivo generado y guardado: {filepath}")
    else:
        # Respaldo en caso de que el modelo use bloques de código markdown convencionales
        print("Aviso: Parseando bloques de código alternativos...")
        code_block_pattern = r"```(?:javascript|js|json|text)?\s*(?:\/\/\s*([a-zA-Z0-9_\-\.]+)\n)?(.*?)```"
        alt_matches = re.findall(code_block_pattern, crew_output, re.DOTALL)
        for designated_name, block_content in alt_matches:
            block_content = block_content.strip()
            detected_name = None
            if designated_name:
                detected_name = designated_name.strip()
            elif "Sequelize" in block_content or "define(" in block_content:
                detected_name = "models.js"
            elif "express()" in block_content or "app.listen" in block_content:
                detected_name = "main.js"
            elif '"dependencies"' in block_content or '"name"' in block_content:
                detected_name = "package.json"
            elif "express" in block_content and "\n" in block_content and "{" not in block_content:
                detected_name = "requirements.txt"
            
            if detected_name and detected_name not in saved_files:
                filepath = os.path.join(output_dir, detected_name)
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write(block_content)
                saved_files.append(detected_name)
                print(f"-> Archivo guardado (parser alternativo): {filepath}")

    return saved_files

def initialize_database_and_dependencies(output_dir: str = "generated_backend"):
    """Instala dependencias con npm y ejecuta la sincronización de modelos para generar database.db."""
    models_file = os.path.join(output_dir, "models.js")
    package_file = os.path.join(output_dir, "package.json")
    
    if not os.path.exists(package_file):
        print("Creando package.json base si no fue generado...")
        default_pkg = {
            "name": "generated-backend",
            "version": "1.0.0",
            "description": "Backend RESTful generado autónomamente por Balam_Developer",
            "main": "main.js",
            "scripts": {"start": "node main.js"},
            "dependencies": {
                "express": "^4.21.2",
                "cors": "^2.8.5",
                "sequelize": "^6.37.5",
                "sqlite3": "^5.1.7",
                "swagger-ui-express": "^5.0.1",
                "dotenv": "^16.4.7"
            }
        }
        with open(package_file, "w", encoding="utf-8") as f:
            json.dump(default_pkg, f, indent=2)

    print("\n--- Instalando dependencias de Node.js en generated_backend/ ---")
    try:
        subprocess.run(["npm", "install"], cwd=output_dir, shell=True, check=True)
        print("✓ Dependencias instaladas con éxito.")
    except Exception as e:
        print(f"Nota: No se pudo ejecutar npm install automáticamente ({e}). Puedes ejecutar 'npm install' manualmente.")

    print("\n--- Inicializando database.db automáticamente ---")
    try:
        init_script = (
            "const { sequelize } = require('./models.js'); "
            "sequelize.sync({ force: false })"
            ".then(() => { console.log('✓ Base de datos database.db inicializada correctamente'); process.exit(0); })"
            ".catch(err => { console.error('Error al sincronizar DB:', err); process.exit(1); });"
        )
        res = subprocess.run(["node", "-e", init_script], cwd=output_dir, shell=True, capture_output=True, text=True)
        if res.returncode == 0:
            print("✓ Archivo 'database.db' creado y listo.")
        else:
            print(f"Salida de inicialización: {res.stdout} {res.stderr}")
    except Exception as e:
        print(f"Nota: La inicialización de la base de datos se ejecutará al iniciar el servidor: {e}")

def run_developer_agent(backlog_file: str = None):
    output_dir = "generated_backend"
    os.makedirs(output_dir, exist_ok=True)

    # Identificar ruta del backlog
    if not backlog_file:
        candidates = [
            "outputs_backlog/backlog_A.json",
            "outputs_backlog/backlog_B.json",
            "backlog_B.json",
            "backlog.json"
        ]
        for c in candidates:
            if os.path.exists(c):
                backlog_file = c
                break

    if not backlog_file or not os.path.exists(backlog_file):
        raise FileNotFoundError("No se encontró el archivo backlog.json en las rutas esperadas.")

    print(f"=== Leyendo Product Backlog desde: {backlog_file} ===")
    with open(backlog_file, "r", encoding="utf-8") as f:
        backlog_content = f.read()

    # Construir la tarea del agente con el Prompt Maestro calibrado
    task_generate_backend = Task(
        description=build_prompt_maestro(backlog_content),
        expected_output=(
            "Archivos models.js, main.js, requirements.txt y package.json generados con sintaxis "
            "completa y delimitadores <<<FILE: nombre>>> ... <<<END_FILE>>>, listos para ejecución."
        ),
        agent=balam_developer
    )

    crew = Crew(
        agents=[balam_developer],
        tasks=[task_generate_backend],
        process=Process.sequential,
        verbose=True
    )

    print("\n=== Ejecutando Balam_Developer (Generación Autónoma del Backend) ===")
    result = crew.kickoff()
    
    raw_output = str(result.raw if hasattr(result, "raw") else result)
    
    print("\n=== Guardando archivos del proyecto backend ===")
    saved = extract_and_save_files(raw_output, output_dir=output_dir)
    print(f"Archivos procesados: {saved}")

    # Inicializar dependencias y base de datos local (database.db)
    initialize_database_and_dependencies(output_dir=output_dir)

    print("\n" + "="*70)
    print("¡PROYECTO BACKEND GENERADO CON ÉXITO EN /generated_backend/!")
    print("Archivos entregables disponibles:")
    print("  1. generated_backend/models.js        (Esquemas y ORM)")
    print("  2. generated_backend/main.js          (Servidor Express y Swagger)")
    print("  3. generated_backend/requirements.txt (Dependencias del servicio)")
    print("  4. generated_backend/package.json     (Configuración NPM)")
    print("  5. generated_backend/database.db      (Base de datos local)")
    print("\nPara iniciar la API localmente ejecuta:")
    print("  cd generated_backend")
    print("  node main.js")
    print("\nDocumentación interactiva disponible en:")
    print("  http://127.0.0.1:8000/docs")
    print("="*70 + "\n")

if __name__ == "__main__":
    backlog_arg = sys.argv[1] if len(sys.argv) > 1 else None
    run_developer_agent(backlog_arg)